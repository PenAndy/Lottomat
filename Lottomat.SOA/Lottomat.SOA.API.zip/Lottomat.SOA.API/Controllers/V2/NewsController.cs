﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Lottomat.Application.Code;
using Lottomat.Application.Entity.SystemManage;
using Lottomat.SOA.API.Controllers.Base;
using Lottomat.Util.Attributes;
using Lottomat.Util.Extension;

namespace Lottomat.SOA.API.Controllers.V2
{
    public class NewsController : BaseApiController
    {
        /// <summary>
        /// 测试是否连接成功
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public HttpResponseMessage HelloWorld()
        {
            LogEntity logEntity = new LogEntity
            {
                CategoryId = (int)CategoryType.Login,
                OperateTypeId = ((int)OperationType.Login).ToString(),
                OperateType = OperationType.Login.GetEnumDescription(),
                OperateAccount = "V2",
                OperateUserId = "V2",
                Module = "V2"
            };

            return logEntity.ToHttpResponseMessage();
        }
    }
}
