﻿using System;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Web.Http;
using System.Web.Http.Cors;
using Lottomat.SOA.API.Filters;
using Lottomat.Util.Extension;
using Lottomat.Util.Log;
using Lottomat.Util.WebControl;

namespace Lottomat.SOA.API.Controllers.Base
{
    /// <summary>
    /// 版 本 1.0
    /// Copyright (c) 2016-2017
    /// 创建人：赵轶
    /// 日 期：2015.11.9 10:45
    /// 描 述：基控Api制器
    /// </summary>
    [EnableCors("*", "*", "GET,POST")]
    [TimingActionFilter]
    public abstract class BaseApiController : ApiController, ILogger
    {
        #region 系统日志
        /// <summary>
        /// 系统日志 主动调用
        /// </summary>
        private readonly LogHelper _logHelper = new LogHelper(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// 系统日志 对try块进行了封装，无返回值
        /// </summary>
        /// <param name="type"></param>
        /// <param name="function">方法名称</param>
        /// <param name="errorHandel">异常处理方式</param>
        /// <param name="tryHandel">调试代码</param>
        /// <param name="catchHandel">异常处理方式</param>
        /// <param name="finallHandel">最终处理方式</param>
        public void Logger(Type type, string function, Action tryHandel, Action<Exception> catchHandel = null,
            Action finallHandel = null, ErrorHandel errorHandel = ErrorHandel.Throw)
        {
            LogHelper.Logger(type, function, errorHandel, tryHandel, catchHandel, finallHandel);
        }

        /// <summary>
        /// 系统日志 对try块进行了封装，有返回值
        /// </summary>
        /// <param name="type"></param>
        /// <param name="function">方法名称</param>
        /// <param name="errorHandel">异常处理方式</param>
        /// <param name="tryHandel">调试代码</param>
        /// <param name="catchHandel">异常处理方式</param>
        /// <param name="finallHandel">最终处理方式</param>
        public T Logger<T>(Type type, string function, Func<T> tryHandel, Func<Exception, T> catchHandel = null,
            Action finallHandel = null, ErrorHandel errorHandel = ErrorHandel.Throw) where T : new()
        {
            T res = LogHelper.Logger(type, function, errorHandel, tryHandel, catchHandel, finallHandel);

            return res;
        }
        #endregion

        #region 默认返回方法
        /// <summary>
        /// 返回成功消息
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns></returns>
        protected virtual string ToJsonResult(object data)
        {
            return data.ToJson();
        }
        /// <summary>
        /// 返回成功消息
        /// </summary>
        /// <param name="message">消息</param>
        /// <returns></returns>
        protected virtual HttpResponseMessage Success(string message)
        {
            return new HttpResponseMessage
            {
                Content =
                    new StringContent(new AjaxResult<string> { type = ResultType.Success, message = message }.ToJson(),
                        Encoding.GetEncoding("UTF-8"), "application/json")
            };
        }
        /// <summary>
        /// 返回成功消息
        /// </summary>
        /// <param name="message">消息</param>
        /// <param name="data">数据</param>
        /// <returns></returns>
        protected virtual HttpResponseMessage Success<T>(string message, T data)
        {
            return new HttpResponseMessage
            {
                Content =
                    new StringContent(
                        new AjaxResult<T> { type = ResultType.Success, message = message, resultdata = data }.ToJson(),
                        Encoding.GetEncoding("UTF-8"), "application/json")
            };
        }
        /// <summary>
        /// 返回失败消息
        /// </summary>
        /// <param name="message">消息</param>
        /// <returns></returns>
        protected virtual HttpResponseMessage Error(string message)
        {
            return new HttpResponseMessage
            {
                Content =
                    new StringContent(new AjaxResult<string> { type = ResultType.Error, message = message }.ToJson(),
                        Encoding.GetEncoding("UTF-8"), "application/json")
            };
        } 
        #endregion
    }
}
