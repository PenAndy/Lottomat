﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http.Filters;
using Lottomat.Application.Code;
using Lottomat.Application.Entity.CommonEntity;
using Lottomat.Application.Entity.ViewModel;
using Lottomat.Cache.Factory;
using Lottomat.Util;
using Lottomat.Util.Extension;

namespace Lottomat.SOA.API.Filters
{
    /// <summary>
    /// 验证
    /// </summary>
    public class ApiSecurityFilter : ActionFilterAttribute
    {
        /// <summary>
        /// 正在请求时
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            BaseJson<string> resultMsg = null;
            //操作上下文请求信息
            HttpRequestMessage request = actionContext.Request;
            //请求方法
            //string method = request.Method.Method;
            string appkey = string.Empty, timestamp = string.Empty, nonce = string.Empty, access_token = string.Empty;

            //string authority = request.RequestUri.Authority;
            //string host = request.RequestUri.Host;
            //string port = request.RequestUri.Port.ToStringEx();
            //if (request.IsLocal())
            //{
            //}
            
            //用户编号
            if (request.Headers.Contains("appkey"))
            {
                appkey = HttpUtility.UrlDecode(request.Headers.GetValues("appkey").FirstOrDefault());
            }
            //时间戳
            if (request.Headers.Contains("timestamp"))
            {
                timestamp = HttpUtility.UrlDecode(request.Headers.GetValues("timestamp").FirstOrDefault());
            }
            //随机数
            if (request.Headers.Contains("nonce"))
            {
                nonce = HttpUtility.UrlDecode(request.Headers.GetValues("nonce").FirstOrDefault());
            }
            //数字签名数据
            if (request.Headers.Contains("access_token"))
            {
                access_token = HttpUtility.UrlDecode(request.Headers.GetValues("access_token").FirstOrDefault());
            }

            //GetToken和Login方法不需要进行签名验证
            string[] exceptRequest = GlobalStaticConstant.NOT_NEED_DIGITAL_SIGNATURE;
            if (exceptRequest.Contains(actionContext.ActionDescriptor.ActionName))
            {
                if (string.IsNullOrEmpty(appkey) || string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce))
                {
                    resultMsg = new BaseJson<string>
                    {
                        Status = (int)JsonObjectStatus.ParameterError,
                        Message = JsonObjectStatus.ParameterError.GetEnumText(),
                        Data = ""
                    };
                    actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
                    base.OnActionExecuting(actionContext);
                    return;
                }
                else
                {
                    base.OnActionExecuting(actionContext);
                    return;
                }
            }

            //判断请求头是否包含以下参数
            if (string.IsNullOrEmpty(appkey) || string.IsNullOrEmpty(timestamp) || string.IsNullOrEmpty(nonce) || string.IsNullOrEmpty(access_token))
            {
                resultMsg = new BaseJson<string>
                {
                    Status = (int)JsonObjectStatus.ParameterError,
                    Message = JsonObjectStatus.ParameterError.GetEnumText(),
                    Data = ""
                };
                actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
                base.OnActionExecuting(actionContext);
                return;
            }

            //判断timespan是否有效
            double qeruest = 0.0;
            //当前时间戳
            double now = (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalMilliseconds;
            //客户端传入得时间戳
            bool timespanvalidate = double.TryParse(timestamp, out qeruest);
            //当前时间必与请求时间差应在1分钟以内才算有效时间戳，防止伪造时间戳
            bool falg = (now - qeruest) > 1 * 60 * 1000;
            //如果时间差大于1分钟或者时间戳转换失败则视为无效时间戳
            if (falg || !timespanvalidate)
            {
                resultMsg = new BaseJson<string>
                {
                    Status = (int)JsonObjectStatus.UrlExpireError,
                    Message = JsonObjectStatus.UrlExpireError.GetEnumText(),
                    Data = ""
                };
                actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
                base.OnActionExecuting(actionContext);
                return;
            }

            //判断token是否有效
            Token_Preview token = CacheFactory.Cache().GetCache<Token_Preview>(appkey);
            string signtoken;
            if (token == null)
            {
                resultMsg = new BaseJson<string>
                {
                    Status = (int)JsonObjectStatus.TokenInvalid,
                    Message = JsonObjectStatus.TokenInvalid.GetEnumText(),
                    Data = ""
                };
                actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
                base.OnActionExecuting(actionContext);
                return;
            }
            else
            {
                signtoken = token.AccessToken;
            }

            #region 请求参数签名，GET请求即参数不带?、&、=符号，如id1nametest;POST请求将数据序列化成Json字符串
            //请求参数签名，GET请求即参数不带?、&、=符号，如id1nametest;POST请求将数据序列化成Json字符串
            //string data;
            //switch (method)//根据请求类型拼接参数
            //{
            //    case "POST":
            //        Stream stream = HttpContext.Current.Request.InputStream;
            //        StreamReader streamReader = new StreamReader(stream);
            //        data = streamReader.ReadToEnd();
            //        break;
            //    case "GET":
            //        NameValueCollection form = HttpContext.Current.Request.QueryString;
            //        //第一步：取出所有get参数
            //        IDictionary<string, string> parameters = new Dictionary<string, string>();
            //        for (int f = 0; f < form.Count; f++)
            //        {
            //            string key = form.Keys[f];
            //            parameters.Add(key, form[key]);
            //        }

            //        // 第二步：把字典按Key的字母顺序排序
            //        IDictionary<string, string> sortedParams = new SortedDictionary<string, string>(parameters);
            //        // ReSharper disable once GenericEnumeratorNotDisposed
            //        IEnumerator<KeyValuePair<string, string>> dem = sortedParams.GetEnumerator();

            //        // 第三步：把所有参数名和参数值串在一起
            //        StringBuilder query = new StringBuilder();
            //        while (dem.MoveNext())
            //        {
            //            string key = dem.Current.Key;
            //            string value = dem.Current.Value;
            //            if (!string.IsNullOrEmpty(key))
            //            {
            //                query.Append(key).Append(value);
            //            }
            //        }
            //        data = query.ToString();
            //        break;
            //    default:
            //        resultMsg = new BaseJson<string>
            //        {
            //            Status = (int)JsonObjectStatus.HttpMehtodError,
            //            Message = JsonObjectStatus.HttpMehtodError.GetEnumText(),
            //            Data = ""
            //        };
            //        actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
            //        base.OnActionExecuting(actionContext);
            //        return;
            //}

            #endregion

            //校验签名信息
            bool result = SignExtension.ValidateSign(timestamp, nonce, appkey, signtoken, access_token);
            if (!result)
            {
                resultMsg = new BaseJson<string>
                {
                    Status = (int)JsonObjectStatus.HttpRequestError,
                    Message = JsonObjectStatus.HttpRequestError.GetEnumText(),
                    Data = ""
                };
                actionContext.Response = resultMsg.ToJson().ToHttpResponseMessage();
                base.OnActionExecuting(actionContext);
                return;
            }
            else
            {
                base.OnActionExecuting(actionContext);
            }
        }

        /// <summary>
        /// 请求完成时
        /// </summary>
        /// <param name="actionExecutedContext"></param>
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            base.OnActionExecuted(actionExecutedContext);
        }

    }
}